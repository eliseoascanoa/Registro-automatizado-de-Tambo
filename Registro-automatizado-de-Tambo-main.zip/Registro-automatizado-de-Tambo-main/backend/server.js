const express = require("express");
const cors = require("cors");
const PDFDocument = require("pdfkit");
const db = require("./db");

const app = express();

app.use(cors());
app.use(express.json());

function obtenerUsuarioId(correo, callback) {
    const sql = `
        SELECT id_usuario
        FROM usuarios
        WHERE correo = ?
        AND estado = 'activo'
        LIMIT 1
    `;

    db.query(sql, [correo], (error, results) => {
        if (error) {
            callback(error);
            return;
        }

        if (results.length === 0) {
            callback(null, null);
            return;
        }

        callback(null, results[0].id_usuario);
    });
}

function registrarMovimiento(datos, callback) {
    obtenerUsuarioId(datos.usuario, (error, idUsuario) => {
        if (error) {
            callback(error);
            return;
        }

        if (!idUsuario) {
            callback(new Error("Usuario no encontrado para registrar movimiento"));
            return;
        }

        const sql = `
            INSERT INTO movimientos
            (id_producto, id_usuario, nombre_producto, tipo_movimiento, cantidad, stock_anterior, stock_nuevo, descripcion)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        db.query(
            sql,
            [
                datos.idProducto,
                idUsuario,
                datos.nombreProducto,
                datos.tipo,
                datos.cantidad,
                datos.stockAnterior,
                datos.stockNuevo,
                datos.descripcion
            ],
            callback
        );
    });
}

function obtenerProductoActivo(id, callback) {
    const sql = `
        SELECT *
        FROM productos
        WHERE id_producto = ?
        AND estado = 'activo'
        LIMIT 1
    `;

    db.query(sql, [id], (error, results) => {
        if (error) {
            callback(error);
            return;
        }

        callback(null, results[0]);
    });
}

// Mostrar productos activos
app.get("/productos", (req, res) => {
    const buscar = req.query.buscar || "";

    const sql = `
        SELECT *
        FROM productos
        WHERE estado = 'activo'
        AND (nombre LIKE ? OR marca LIKE ?)
    `;

    const filtro = `%${buscar}%`;

    db.query(sql, [filtro, filtro], (error, results) => {
        if (error) {
            return res.status(500).json({ mensaje: "Error al obtener productos" });
        }

        res.json(results);
    });
});

// Agregar producto
app.post("/productos", (req, res) => {
    const { nombre, marca, presentacion, stock, stock_minimo, imagen, usuario } = req.body;

    const sql = `
        INSERT INTO productos
        (nombre, categoria, marca, presentacion, stock, stock_minimo, imagen)
        VALUES (?, 'Gaseosa', ?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [nombre, marca, presentacion, stock, stock_minimo, imagen],
        (error, result) => {
            if (error) {
                return res.status(500).json({ mensaje: "Error al agregar producto" });
            }

            registrarMovimiento(
                {
                    idProducto: result.insertId,
                    nombreProducto: nombre,
                    usuario,
                    tipo: "creacion",
                    cantidad: stock,
                    stockAnterior: 0,
                    stockNuevo: stock,
                    descripcion: "Producto creado desde el panel administrador"
                },
                (movementError) => {
                    if (movementError) {
                        return res.status(500).json({ mensaje: "Producto creado, pero no se registró el movimiento" });
                    }

                    res.json({
                        mensaje: "Producto agregado correctamente",
                        id_producto: result.insertId
                    });
                }
            );
        }
    );
});

// Aumentar stock
app.put("/productos/:id/aumentar", (req, res) => {
    const { cantidad, usuario } = req.body;
    const { id } = req.params;

    obtenerProductoActivo(id, (selectError, producto) => {
        if (selectError) {
            return res.status(500).json({ mensaje: "Error al obtener producto" });
        }

        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" });
        }

        const stockNuevo = producto.stock + cantidad;
        const sql = `
            UPDATE productos
            SET stock = ?
            WHERE id_producto = ?
            AND estado = 'activo'
        `;

        db.query(sql, [stockNuevo, id], (error) => {
            if (error) {
                return res.status(500).json({ mensaje: "Error al aumentar stock" });
            }

            registrarMovimiento(
                {
                    idProducto: producto.id_producto,
                    nombreProducto: producto.nombre,
                    usuario,
                    tipo: "entrada",
                    cantidad,
                    stockAnterior: producto.stock,
                    stockNuevo,
                    descripcion: "Ingreso de unidades desde la web"
                },
                (movementError) => {
                    if (movementError) {
                        return res.status(500).json({ mensaje: "Stock actualizado, pero no se registró el movimiento" });
                    }

                    res.json({ mensaje: "Stock aumentado correctamente" });
                }
            );
        });
    });
});

// Disminuir stock
app.put("/productos/:id/disminuir", (req, res) => {
    const { cantidad, usuario } = req.body;
    const { id } = req.params;

    obtenerProductoActivo(id, (selectError, producto) => {
        if (selectError) {
            return res.status(500).json({ mensaje: "Error al obtener producto" });
        }

        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" });
        }

        if (producto.stock < cantidad) {
            return res.status(400).json({ mensaje: "Stock insuficiente" });
        }

        const stockNuevo = producto.stock - cantidad;
        const sql = `
            UPDATE productos
            SET stock = ?
            WHERE id_producto = ?
            AND estado = 'activo'
        `;

        db.query(sql, [stockNuevo, id], (error) => {
            if (error) {
                return res.status(500).json({ mensaje: "Error al disminuir stock" });
            }

            registrarMovimiento(
                {
                    idProducto: producto.id_producto,
                    nombreProducto: producto.nombre,
                    usuario,
                    tipo: "salida",
                    cantidad,
                    stockAnterior: producto.stock,
                    stockNuevo,
                    descripcion: "Retiro de unidades desde la web"
                },
                (movementError) => {
                    if (movementError) {
                        return res.status(500).json({ mensaje: "Stock actualizado, pero no se registró el movimiento" });
                    }

                    res.json({ mensaje: "Stock disminuido correctamente" });
                }
            );
        });
    });
});

// Eliminación lógica
app.put("/productos/:id/eliminar-logico", (req, res) => {
    const { usuario } = req.body;
    const { id } = req.params;

    obtenerProductoActivo(id, (selectError, producto) => {
        if (selectError) {
            return res.status(500).json({ mensaje: "Error al obtener producto" });
        }

        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" });
        }

        const sql = `
            UPDATE productos
            SET estado = 'inactivo'
            WHERE id_producto = ?
        `;

        db.query(sql, [id], (error) => {
            if (error) {
                return res.status(500).json({ mensaje: "Error al ocultar producto" });
            }

            registrarMovimiento(
                {
                    idProducto: producto.id_producto,
                    nombreProducto: producto.nombre,
                    usuario,
                    tipo: "eliminacion_logica",
                    cantidad: 0,
                    stockAnterior: producto.stock,
                    stockNuevo: producto.stock,
                    descripcion: "Producto ocultado desde la web"
                },
                (movementError) => {
                    if (movementError) {
                        return res.status(500).json({ mensaje: "Producto ocultado, pero no se registró el movimiento" });
                    }

                    res.json({ mensaje: "Producto ocultado correctamente" });
                }
            );
        });
    });
});

// Eliminación física
app.delete("/productos/:id", (req, res) => {
    const { usuario } = req.body;
    const { id } = req.params;

    const sqlProducto = `
        SELECT *
        FROM productos
        WHERE id_producto = ?
        LIMIT 1
    `;

    db.query(sqlProducto, [id], (selectError, results) => {
        if (selectError) {
            return res.status(500).json({ mensaje: "Error al obtener producto" });
        }

        if (results.length === 0) {
            return res.status(404).json({ mensaje: "Producto no encontrado" });
        }

        const producto = results[0];

        registrarMovimiento(
            {
                idProducto: producto.id_producto,
                nombreProducto: producto.nombre,
                usuario,
                tipo: "eliminacion_fisica",
                cantidad: 0,
                stockAnterior: producto.stock,
                stockNuevo: 0,
                descripcion: "Producto eliminado definitivamente de la base de datos"
            },
            (movementError) => {
                if (movementError) {
                    return res.status(500).json({ mensaje: "No se registró el movimiento de eliminación física" });
                }

                const sqlDelete = `
                    DELETE FROM productos
                    WHERE id_producto = ?
                `;

                db.query(sqlDelete, [id], (deleteError) => {
                    if (deleteError) {
                        return res.status(500).json({ mensaje: "Error al eliminar físicamente" });
                    }

                    res.json({ mensaje: "Producto eliminado físicamente" });
                });
            }
        );
    });
});

app.get("/movimientos", (req, res) => {
    const sql = `
        SELECT
            m.id_movimiento,
            m.nombre_producto,
            m.tipo_movimiento,
            m.cantidad,
            m.stock_anterior,
            m.stock_nuevo,
            m.descripcion,
            m.fecha_movimiento,
            u.nombre AS usuario,
            u.rol
        FROM movimientos m
        INNER JOIN usuarios u ON u.id_usuario = m.id_usuario
        ORDER BY m.fecha_movimiento DESC
        LIMIT 50
    `;

    db.query(sql, (error, results) => {
        if (error) {
            return res.status(500).json({ mensaje: "Error al obtener movimientos" });
        }

        res.json(results);
    });
});

app.get("/reportes/movimientos/pdf", (req, res) => {
    const sql = `
        SELECT
            m.nombre_producto,
            m.tipo_movimiento,
            m.cantidad,
            m.stock_anterior,
            m.stock_nuevo,
            m.descripcion,
            DATE_FORMAT(m.fecha_movimiento, '%d/%m/%Y %H:%i:%s') AS fecha,
            u.nombre AS usuario,
            u.rol
        FROM movimientos m
        INNER JOIN usuarios u ON u.id_usuario = m.id_usuario
        ORDER BY m.fecha_movimiento DESC
    `;

    db.query(sql, (error, movimientos) => {
        if (error) {
            return res.status(500).json({ mensaje: "Error al generar reporte" });
        }

        const doc = new PDFDocument({ margin: 42, size: "A4" });

        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", "attachment; filename=reporte-movimientos-tambo.pdf");

        doc.pipe(res);
        doc.fontSize(20).fillColor("#662d91").text("Tambo+ Reporte de Movimientos", { align: "center" });
        doc.moveDown(0.5);
        doc.fontSize(10).fillColor("#333").text(`Generado: ${new Date().toLocaleString("es-PE")}`, { align: "center" });
        doc.moveDown();
        doc.moveTo(42, doc.y).lineTo(553, doc.y).strokeColor("#ffcc00").lineWidth(2).stroke();
        doc.moveDown();

        if (movimientos.length === 0) {
            doc.fontSize(12).fillColor("#333").text("No hay movimientos registrados.");
        }

        movimientos.forEach((movimiento, index) => {
            if (doc.y > 700) {
                doc.addPage();
            }

            doc.roundedRect(42, doc.y, 511, 88, 6).strokeColor("#e5e7eb").lineWidth(1).stroke();
            doc.moveDown(0.4);
            doc.fontSize(12).fillColor("#111827").text(`${index + 1}. ${movimiento.nombre_producto}`, 56, doc.y);
            doc.fontSize(9).fillColor("#662d91").text(`Movimiento: ${movimiento.tipo_movimiento}`, 56);
            doc.fillColor("#333").text(`Cantidad: ${movimiento.cantidad} | Stock anterior: ${movimiento.stock_anterior} | Stock nuevo: ${movimiento.stock_nuevo}`, 56);
            doc.text(`Usuario: ${movimiento.usuario} (${movimiento.rol})`, 56);
            doc.text(`Fecha: ${movimiento.fecha}`, 56);
            doc.fillColor("#6b7280").text(`Detalle: ${movimiento.descripcion || "Sin detalle"}`, 56);
            doc.moveDown(1.4);
        });

        doc.end();
    });
});

app.listen(3000, () => {
    console.log("Servidor corriendo en http://localhost:3000");
});
