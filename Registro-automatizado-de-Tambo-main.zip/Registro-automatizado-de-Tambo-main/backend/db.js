const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "J4y/jeremy",
    database: "inventario_tambo"
});

connection.connect((error) => {
    if (error) {
        console.error("Error al conectar con MySQL:", error);
        return;
    }

    console.log("Conectado a la base de datos inventario_tambo");
});

module.exports = connection;